package com.example.tourismmanagement.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tourismmanagement.DataBase.DBProvince;
import com.example.tourismmanagement.InterFace.UpdateProvinceActivity;
import com.example.tourismmanagement.Model.CustomerModel;
import com.example.tourismmanagement.R;

import java.util.ArrayList;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.MyViewHolder> {
    private Context context;
    private Activity activity;
    private ArrayList<CustomerModel> customerModels;

    public CustomerAdapter(Context context, ArrayList<CustomerModel> customerModels) {
        this.context = context;
        this.customerModels = customerModels;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.row_customer, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final CustomerModel customer = customerModels.get(position);

        holder.txt_c_code.setText(customer.getC_code());
        holder.txt_c_name.setText(customer.getC_fullname());
        holder.txt_c_address.setText(customer.getC_address());
        holder.img_c.setImageResource(R.drawable.usa);

//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                //Toast.makeText(view.getContext(), txt_p_name.getText() + "", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent((Activity)context, UpdateProvinceActivity.class);
//                Bundle bundle = new Bundle();
//                bundle.putString("p_code", province.getP_code());
//                intent.putExtras(bundle);
//                ((Activity) context).startActivity(intent);
//            }
//        });
//        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                DBProvince dbProvince = new DBProvince(context);
//                dbProvince.deleteProvince(province.getP_code());
//                return false;
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return customerModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt_c_code, txt_c_name, txt_c_address;
        ImageView img_c;
        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            txt_c_code = itemView.findViewById(R.id.textViewRow_c_code);
            txt_c_name = itemView.findViewById(R.id.textViewRow_c_name);
            txt_c_address = itemView.findViewById(R.id.textViewRow_c_Address);
            img_c = itemView.findViewById(R.id.imageView_c);
        }


    }
}
