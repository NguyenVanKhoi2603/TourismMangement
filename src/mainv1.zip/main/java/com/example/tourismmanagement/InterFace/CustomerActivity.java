package com.example.tourismmanagement.InterFace;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.tourismmanagement.Adapter.CustomAdapter;
import com.example.tourismmanagement.Adapter.CustomerAdapter;
import com.example.tourismmanagement.DataBase.DBCustomer;
import com.example.tourismmanagement.DataBase.DBProvince;
import com.example.tourismmanagement.Model.CustomerModel;
import com.example.tourismmanagement.Model.ProvinceModel;
import com.example.tourismmanagement.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class CustomerActivity extends AppCompatActivity {
    FloatingActionButton floatbtn_add;
    RecyclerView recyclerView_customer;
    DBCustomer dbCustomer;
    ArrayList<CustomerModel> data_customer = new ArrayList<>();
    CustomerAdapter customerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        setControl();
        setEvent();
    }

    private void setEvent() {
        dbCustomer = new DBCustomer(CustomerActivity.this);
        loadData();
        floatbtn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CustomerActivity.this, AddCustomerActivity.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        floatbtn_add = findViewById(R.id.floatingActionBtn_Customer);
        recyclerView_customer = findViewById(R.id.recycleViewCustomer);
    }

    private void loadData() {
        try {
            customerAdapter = new CustomerAdapter(CustomerActivity.this,  dbCustomer.getListCustomer());
            recyclerView_customer.setAdapter(customerAdapter);
            recyclerView_customer.setLayoutManager(new LinearLayoutManager(CustomerActivity.this));
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Chua co du lieu", Toast.LENGTH_SHORT).show();
        }
    }
}